import io,json,urllib.error
import pytest
from healthcare_quality.ollama_provider import OllamaProvider,ProviderError
pytestmark=[pytest.mark.unit,pytest.mark.regression]
def test_local_http_schema_error_body_is_retained(monkeypatch):
 def rejected(*args,**kwargs):raise urllib.error.HTTPError('http://127.0.0.1:11434/api/generate',400,'Bad Request',{},io.BytesIO(b'{"error":"unsupported schema"}'))
 monkeypatch.setattr('urllib.request.urlopen',rejected)
 with pytest.raises(ProviderError) as error:OllamaProvider('advanced').generate('qwen2.5-coder:3b','fixture',{})
 assert error.value.raw_response['http_status']==400 and 'unsupported schema' in error.value.raw_response['body'] and not error.value.raw_response['truncated']
