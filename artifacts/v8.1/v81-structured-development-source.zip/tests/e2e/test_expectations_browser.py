import pytest
from playwright.sync_api import expect
pytestmark=[pytest.mark.e2e,pytest.mark.regression]
@pytest.mark.parametrize('width',[390,1440])
def test_model_only_dashboard_is_explicit_and_distinguishes_stages(page,live_url,width):
 page.set_viewport_size({'width':width,'height':1000});posts=[];page.on('request',lambda r:posts.append(r.url) if r.method=='POST' else None);page.goto(live_url+'/#workbench');panel=page.locator('#expectations-v81');panel.scroll_into_view_if_needed();expect(page.locator('#ev81-start')).to_be_enabled();expect(page.locator('#ev81-task option')).to_have_count(14);assert not posts;expect(panel).to_contain_text('after both answers are frozen');expect(panel).to_contain_text('80%');assert page.evaluate('document.documentElement.scrollWidth<=innerWidth');expect(page.locator('#ev81-stage option')).to_have_count(2)

def test_unavailable_configuration_keeps_generation_disabled(page,live_url):
 page.route('**/api/advanced/expectations',lambda route:route.fulfill(status=503,json={'error':'configuration unavailable'}));page.goto(live_url+'/#workbench');expect(page.locator('#ev81-status')).to_contain_text('configuration unavailable');expect(page.locator('#ev81-start')).to_be_disabled()
